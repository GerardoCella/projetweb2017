<?php 
	$titre = "Exercices 6b - Creation de la class Form.";
    require "header.php"; 
?>
<h1><?= $titre ?></h1>
<div class="container">		
<?php
    require 'OO/Form.php';
    $form = new Form('formulaire', 'formulaire', 'post', 'http://dero-promsocatc.alwaysdata.net/index.php');

    $form->SetText('*Nom :', 'NOM', 'NOM', 'Veuillez entrez votre nom', '', true);
    $form->SetEmail('*Email :', 'EMAIL', 'EMAIL', 'email@fournisseur.com', '', true);
    $form->SetSubmit('submit', 'Envoyez');



    echo $form->GetForm();
?>
</div>
<?php require "footer.php"; ?>
