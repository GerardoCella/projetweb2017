<?php
    session_start();
    session_destroy();
    require 'Page1.php';
?>