<?php
class Form
{
    private $_name;
    private $_id;
    private $_method;
    private $_action;
    private $_list;

    public function __construct($name, $id, $method, $action)
    {
        $this->_name = $name;
        $this->_id = $id;
        $this->_method = $method;
        $this->_action = $action;
    }

    public function SetText($label, $name, $id, $placeholder='', $value='', $required=false)
    {
        $this->SetInput('text', $label, $name, $id, $placeholder, $value, $required);        
    }

    public function SetEmail($label, $name, $id, $placeholder='', $value='', $required=false)
    {
        $this->SetInput('email', $label, $name, $id, $placeholder, $value, $required);
    }


    private function SetInput($type, $label, $name, $id, $placeholder, $value, $required){
        $html = '<label for="'. $id . '">'. $label . '</label>';
        $html .= '<br/>';
        $html .= '<input type="' . $type . '" id="' . $id . '" name="' . $name . '" placeholder="' . $placeholder .'" value="' . $value . '" ';
        $html .= $required ? 'required ' : '';
        $html .= '/>';
        $html .= '<br/>';
        
        $this->_list[] = $html;
    }

    public function SetSubmit($name, $value, $id=''){
        $html = '<input type="submit" name="' . $name . '" id="' . $id . '" value="' . $value . '"/>';
        
        $this->_list[] = $html;
    }



    public function GetForm()
    {
        $html = '<form action="' . $this->_action . '" method="' . $this->_method . '">';
        foreach ($this->_list as $value) {
            $html .= $value;
        }
        $html .= '</form>';

        return $html;
    }
}