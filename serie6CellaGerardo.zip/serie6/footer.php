	<footer class="container-fluid">
		Fait par Cella, Gerardo <a href="#navbar">haut de page</a>
	</footer>
</body>
</html>