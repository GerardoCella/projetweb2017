<?php 
	require "core.php";
	echo 'index.php';
	$Tabletest=Model::load("tabletest");
	require '../vue/index.php'
?>
