<?php
	require('../model/model.php');
	echo 'core.php';
?>