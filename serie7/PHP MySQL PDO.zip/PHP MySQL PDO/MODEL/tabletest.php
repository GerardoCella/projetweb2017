<?php
class tabletest extends Model{
	var $table = "tabletest";	
	var $id ;
	var $PK = "ID";
	var $data ; 
}

?>